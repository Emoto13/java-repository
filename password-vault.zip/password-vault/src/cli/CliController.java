package cli;

public class CliController {
}
