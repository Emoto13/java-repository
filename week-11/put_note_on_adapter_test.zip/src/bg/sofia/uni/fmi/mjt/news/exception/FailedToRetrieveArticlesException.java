package bg.sofia.uni.fmi.mjt.news.exception;

public class FailedToRetrieveArticlesException extends Exception {
    public FailedToRetrieveArticlesException(String message) {
        super(message);
    }
}
