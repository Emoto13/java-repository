package bg.sofia.uni.fmi.mjt.grading.simulator.assignment;

public record Assignment(int studentFn, String studentName, AssignmentType type) {
}