package test.bg.sofia.uni.fmi.mjt.test.bg.sofia.uni.fmi.mjt.myfitnesspal.nutrition;

import bg.sofia.uni.fmi.mjt.myfitnesspal.nutrition.NutritionInfo;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TestNutritionInfo {
    @Test
    void test() {
        assertThrows(IllegalArgumentException.class, () -> {
            new NutritionInfo(0, 50, 50);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new NutritionInfo(50, 0, 50);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new NutritionInfo(50, 50, 0);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new NutritionInfo(1, 50, 1);
        });

        NutritionInfo ni = new NutritionInfo(30, 30, 40);
        assertEquals(600.0, ni.calories());
    }

}
