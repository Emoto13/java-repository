package test.bg.sofia.uni.fmi.mjt.myfitnesspal;

import org.junit.jupiter.api.Test;

public class TestUnknownFoodException {
    @Test
    void test() {}

}
