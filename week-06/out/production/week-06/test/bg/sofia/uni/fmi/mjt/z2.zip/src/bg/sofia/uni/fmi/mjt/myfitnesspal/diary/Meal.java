package bg.sofia.uni.fmi.mjt.myfitnesspal.diary;

public enum Meal {
    BREAKFAST,
    LUNCH,
    DINNER,
    SNACKS
}
