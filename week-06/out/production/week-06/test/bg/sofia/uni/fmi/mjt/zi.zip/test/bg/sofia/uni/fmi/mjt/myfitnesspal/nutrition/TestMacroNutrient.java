package test.bg.sofia.uni.fmi.mjt.myfitnesspal.nutrition;

import org.junit.jupiter.api.Test;

public class TestMacroNutrient {
    @Test
    void test() {}
}
