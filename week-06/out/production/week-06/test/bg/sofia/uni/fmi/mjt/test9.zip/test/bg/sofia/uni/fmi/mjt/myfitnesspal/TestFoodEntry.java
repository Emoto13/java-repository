package test.bg.sofia.uni.fmi.mjt.myfitnesspal;

import org.junit.jupiter.api.Test;

public class TestFoodEntry {
    @Test
    void test() {}
}
