package bg.sofia.uni.fmi.mjt.myfitnesspal.nutrition;

import org.junit.jupiter.api.Test;

public class MacroNutrientTest {
    @Test
    void test() {}
}
